import SocketContext, { withSocket } from './withSocket';
import CustomSocket from './socket';

export default CustomSocket;

export { SocketContext, withSocket };